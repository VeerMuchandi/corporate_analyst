from .tool_context import ToolContext


def exit_loop(tool_context: ToolContext):
  """Exits the loop.

  Call this function only when you are instructed to do so.
  """
  tool_context.actions.escalate = True
