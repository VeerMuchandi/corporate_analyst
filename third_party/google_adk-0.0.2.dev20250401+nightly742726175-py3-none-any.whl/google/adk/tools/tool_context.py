# Copyright 2025 Google LLC
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from __future__ import annotations

from typing import Any
from typing import Optional, TYPE_CHECKING

from ..agents.callback_context import CallbackContext

if TYPE_CHECKING:
  from ..agents.invocation_context import InvocationContext
  from ..events.event_actions import EventActions
  from ..memory.base_memory_service import SearchMemoryResponse


class ToolContext(CallbackContext):

  def __init__(
      self,
      invocation_context: InvocationContext,
      *,
      function_call_id: Optional[str] = None,
      event_actions: Optional[EventActions] = None,
      auth_response: Any = None,
  ):
    super().__init__(invocation_context, event_actions=event_actions)
    self.function_call_id = function_call_id
    self.auth_response = auth_response

  @property
  def actions(self) -> EventActions:
    return self._event_actions

  def request_credential(self, auth_config: dict) -> None:
    if not self.function_call_id:
      raise ValueError('function_call_id is not set.')
    self._event_actions.requested_auth_configs[self.function_call_id] = (
        auth_config
    )

  def get_auth_response(self) -> dict[str, Any]:
    return self.auth_response

  def list_artifacts(self) -> list[str]:
    """Lists the filenames of the artifacts attached to the current session."""
    if self._invocation_context.artifact_service is None:
      raise ValueError('Artifact service is not initialized.')
    return self._invocation_context.artifact_service.list_artifact_keys(
        self._invocation_context.app_name,
        self._invocation_context.user_id,
        self._invocation_context.session.id,
    )

  def search_memory(self, query: str) -> 'SearchMemoryResponse':
    """Searches the memory of the current user."""
    if self._invocation_context.memory_service is None:
      raise ValueError('Memory service is not available.')
    return self._invocation_context.memory_service.search_memory(
        self._invocation_context.app_name,
        self._invocation_context.user_id,
        query,
    )
