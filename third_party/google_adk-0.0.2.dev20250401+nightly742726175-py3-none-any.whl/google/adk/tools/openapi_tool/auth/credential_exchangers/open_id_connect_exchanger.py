# Copyright 2025 Google LLC
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Credential fetcher for OpenID Connect."""

from typing import Optional

from authlib.integrations.requests_client import OAuth2Session

from ..auth_credential import (
    AuthCredential,
    AuthCredentialTypes,
    HttpAuth,
    HttpCredentials,
    OAuth2AuthResponse,
)
from ..auth_schemes import AuthScheme, AuthSchemeType
from ..auth_schemes import OpenIdConnectWithConfig
from .base_credential_exchanger import AuthCredentialMissingError, BaseAuthCredentialExchanger


class OpenIdConnectCredentialExchanger(BaseAuthCredentialExchanger):
  """Fetches credentials for OpenID Connect."""

  def _check_scheme_credential_type(
      self,
      auth_scheme: AuthScheme,
      auth_credential: Optional[AuthCredential] = None,
  ):
    if not auth_credential:
      raise ValueError(
          "auth_credential is empty. Please create AuthCredential using"
          " OpenIdConnectAuth."
      )

    if auth_scheme.type_ != AuthSchemeType.openIdConnect:
      raise ValueError(
          "Invalid security scheme for OpenID Connect."
          " OpenIdConnectCredentialExchanger expect"
          " AuthSchemeType.openIdConnect auth scheme, but got"
          f" {auth_scheme.type_}"
      )

    if not isinstance(auth_scheme, OpenIdConnectWithConfig):
      raise ValueError(
          "OpenIdConnect config is not fetched. Please use"
          " auth_helpers.openid_url_to_scheme_credential to fetch OpenIDConnect"
          " details first."
      )

    if not auth_credential.open_id_connect and not auth_credential.http:
      raise ValueError(
          "auth_credential is not configured with open_id_connect. Please"
          " create AuthCredential and set OpenIdConnectAuth."
      )

    if not (
        auth_credential.open_id_connect.client_id
        and auth_credential.open_id_connect.client_secret
        and auth_credential.open_id_connect.redirect_uri
    ):
      raise AuthCredentialMissingError(
          "OpenID Connect credentials (client_id, client_secret, redirect_uri)"
          " are missing. Please provide them."
      )

  def generate_auth_uri(
      self,
      auth_scheme: OpenIdConnectWithConfig,
      auth_credential: Optional[AuthCredential] = None,
  ) -> AuthCredential:
    """Generates an reponse containing the auth uri for user to sign in.

    Args:
        auth_scheme: The OpenID Connect auth scheme.
        auth_credential: The auth credential.

    Returns:
        An AuthCredential object containing the auth URI and state.

    Raises:
        ValueError: If the authorization endpoint is not configured in the auth
            scheme.
        ValueError: If the auth_credential is not configured with
            open_id_connect.
    """
    if (
        not hasattr(auth_scheme, "authorization_endpoint")
        or not auth_scheme.authorization_endpoint
    ):
      raise ValueError(
          "authorization_endpoint endpoint is empty. Please fetch the"
          " authentication_endpoint from OpenID Connect Config URL first."
      )
    authorization_endpoint = auth_scheme.authorization_endpoint
    scopes = ",".join(auth_scheme.scopes)
    redirect_uri = auth_credential.open_id_connect.redirect_uri or None
    client = OAuth2Session(
        auth_credential.open_id_connect.client_id,
        auth_credential.open_id_connect.client_secret,
        scope=scopes,
        redirect_uri=redirect_uri,
    )
    uri, state = client.create_authorization_url(url=authorization_endpoint)
    auth_credential.oauth2_response = OAuth2AuthResponse(
        auth_uri=uri, state=state
    )
    return auth_credential

  def generate_auth_token(
      self,
      auth_scheme: OpenIdConnectWithConfig,
      auth_credential: Optional[AuthCredential] = None,
  ) -> AuthCredential:
    """Generates an auth token from the authorization response.

    Args:
        auth_scheme: The OpenID Connect auth scheme.
        auth_credential: The auth credential.

    Returns:
        An AuthCredential object containing the access token.

    Raises:
        ValueError: If the token endpoint is not configured in the auth
            scheme.
        AuthCredentialMissingError: If the access token cannot be retrieved
            from the token endpoint.
    """
    if not hasattr(auth_scheme, "token_endpoint"):
      raise ValueError(
          "token_endpoint endpoint is empty. Please fetch the"
          " token_endpoint from OpenID Connect Config URL first."
      )

    token_endpoint = auth_scheme.token_endpoint
    scopes = ",".join(auth_scheme.scopes)
    redirect_uri = auth_credential.open_id_connect.redirect_uri or None

    client = OAuth2Session(
        auth_credential.open_id_connect.client_id,
        auth_credential.open_id_connect.client_secret,
        scope=scopes,
        redirect_uri=redirect_uri,
    )
    try:
      # Exchange the authorization code for an access token.
      token = client.fetch_token(
          token_endpoint,
          authorization_response=auth_credential.oauth2_response.auth_response,
          grant_type="authorization_code",
      )

      if "access_token" not in token:
        raise AuthCredentialMissingError(
            f"Failed to retrieve access token. Response: {token}"
        )

      # Return the access token as a bearer token.
      updated_credential = AuthCredential(
          auth_type=AuthCredentialTypes.HTTP,  # Store as a bearer token
          http=HttpAuth(
              scheme="bearer",
              credentials=HttpCredentials(token=token["access_token"]),
          ),
      )
      return updated_credential
    except Exception as e:
      raise AuthCredentialMissingError(
          f"Failed to fetch OpenID Connect token: {e}"
      ) from e

  def exchange_credential(
      self,
      auth_scheme: AuthScheme,
      auth_credential: Optional[AuthCredential] = None,
  ) -> AuthCredential:
    """Exchanges the OpenID Connect auth credential for an access token or an auth URI.

    Args:
        auth_scheme: The auth scheme.
        auth_credential: The auth credential.

    Returns:
        An AuthCredential object containing the access token.

    Raises:
        ValueError: If the auth scheme or auth credential is invalid.
    """
    # TODO(cheliu): Implement token refresh flow

    self._check_scheme_credential_type(auth_scheme, auth_credential)

    # Step 1: If oauth code is not yet generated in the auth credential,
    # generate a auth url from scheme and secrets
    if not auth_credential or not auth_credential.oauth2_response:
      return self.generate_auth_uri(auth_scheme, auth_credential)

    # Step 2: If auth code is acquired from auth_response, fetch auth token.
    if (
        auth_credential.oauth2_response
        and auth_credential.oauth2_response.auth_response
    ):
      return self.generate_auth_token(auth_scheme, auth_credential)

    # Step 3: If token is already HTTPBearer token, do nothing assuming that
    # this token is valid.
    if auth_credential.auth_type == AuthCredentialTypes.HTTP:
      return auth_scheme, auth_credential

    raise ValueError("Auth ")

    raise ValueError("Auth ")
    raise ValueError("Auth ")
