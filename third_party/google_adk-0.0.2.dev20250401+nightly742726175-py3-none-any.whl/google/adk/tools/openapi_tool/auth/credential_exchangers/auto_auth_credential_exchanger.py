# Copyright 2025 Google LLC
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from typing import Dict, Optional, Type

from ..auth_credential import (
    AuthCredential,
    AuthCredentialTypes,
)
from ..auth_schemes import AuthScheme
from .base_credential_exchanger import BaseAuthCredentialExchanger
from .open_id_connect_exchanger import OpenIdConnectCredentialExchanger
from .service_account_exchanger import ServiceAccountCredentialExchanger


class NoExchangeCredentialExchanger(BaseAuthCredentialExchanger):
  """No-op credential exchanger."""

  def exchange_credential(
      self,
      auth_scheme: AuthScheme,
      auth_credential: Optional[AuthCredential] = None,
  ) -> AuthCredential:
    raise AssertionError("NoExchangeCredentialExchanger should not be invoked")


class AutoAuthCredentialExchanger(BaseAuthCredentialExchanger):
  """Automatically selects the appropriate credential exchanger based on the auth scheme.

  Optionally, an override can be provided to use a specific exchanger for a
  given auth scheme.

  Example (common case):
  ```
  exchanger = AutoAuthCredentialExchanger()
  auth_credential = exchanger.exchange_credential(
      auth_scheme=service_account_scheme,
      auth_credential=service_account_credential,
  )
  # Returns an oauth token in the form of a bearer token.
  ```

  Example (use CustomAuthExchanger for OAuth2):
  ```
  exchanger = AutoAuthCredentialExchanger(
      custom_exchangers={
          AuthScheme.OAUTH2: CustomAuthExchanger,
      }
  )
  ```

  Attributes:
    exchangers: A dictionary mapping auth scheme to credential exchanger class.
  """

  def __init__(
      self,
      custom_exchangers: Optional[
          Dict[str, Type[BaseAuthCredentialExchanger]]
      ] = None,
  ):
    """Initializes the AutoAuthCredentialExchanger.

    Args:
      custom_exchangers: Optional dictionary for adding or overriding auth
        exchangers. The key is the auth scheme, and the value is the credential
        exchanger class.
    """
    self.exchangers = {
        AuthCredentialTypes.HTTP: NoExchangeCredentialExchanger,
        AuthCredentialTypes.API_KEY: NoExchangeCredentialExchanger,
        AuthCredentialTypes.OAUTH2: self._get_oauth2_exchanger,
        AuthCredentialTypes.OPEN_ID_CONNECT: OpenIdConnectCredentialExchanger,
        AuthCredentialTypes.SERVICE_ACCOUNT: ServiceAccountCredentialExchanger,
    }

    if custom_exchangers:
      self.exchangers.update(custom_exchangers)

  def _get_oauth2_exchanger(self, auth_scheme: AuthScheme):
    """Helper function to determine correct OAuth exchanger."""
    # TODO(cheliu): Add support for OAuth flows
    raise ValueError("OAuth2 flow is not supported yet.")

  def exchange_credential(
      self,
      auth_scheme: AuthScheme,
      auth_credential: Optional[AuthCredential] = None,
  ) -> AuthCredential:
    """Automatically exchanges for the credential uses the appropriate credential exchanger.

    Args:
        auth_scheme (AuthScheme): The security scheme.
        auth_credential (AuthCredential): Optional. The authentication
          credential.

    Returns: (AuthCredential)
        A new AuthCredential object containing the exchanged credential.

    Raises:
        ValueError: If an unsupported authentication scheme is encountered.
    """
    if not auth_credential:
      raise ValueError(
          "auth_credential is empty. Please make sure auth credential is"
          " correctly generated and passed to Tool."
      )

    if auth_credential.auth_type == AuthCredentialTypes.OAUTH2:
      exchanger_class = self._get_oauth2_exchanger(auth_scheme)
    else:
      exchanger_class = self.exchangers.get(
          auth_credential.auth_type if auth_credential else None
      )

    if not exchanger_class:
      raise ValueError(
          f"Unsupported authentication scheme: {auth_credential.auth_type}"
      )

    if exchanger_class == NoExchangeCredentialExchanger:
      return auth_credential

    exchanger = exchanger_class()
    return exchanger.exchange_credential(auth_scheme, auth_credential)
