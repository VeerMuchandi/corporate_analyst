# Copyright 2025 Google LLC
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Handles auth information to build the LLM request."""

from __future__ import annotations

from typing import AsyncGenerator
from typing import Generator
from typing import TYPE_CHECKING

from typing_extensions import override

from ...agents.invocation_context import InvocationContext
from ...events.event import Event
from ...models.llm_request import LlmRequest
from ...tools.auth_tool import AuthToolArguments
from . import functions
from ._base_llm_processor import BaseLlmRequestProcessor
from .functions import REQUEST_EUC_FUNCTION_CALL_NAME

if TYPE_CHECKING:
  from ...agents.llm_agent import LlmAgent


class _AuthLlmRequestProcessor(BaseLlmRequestProcessor):

  @override
  async def run_async(
      self, invocation_context: InvocationContext, llm_request: LlmRequest
  ) -> AsyncGenerator[Event, None]:
    from ...agents.llm_agent import LlmAgent

    agent = invocation_context.agent
    if not isinstance(agent, LlmAgent):
      return
    events = invocation_context.session.events
    if not events:
      return
    request_euc_function_call_response_event = events[-1]
    responses = (
        request_euc_function_call_response_event.get_function_responses()
    )
    if not responses:
      return

    auth_responses_by_long_running_tool_id = {}

    for function_call_response in responses:
      if function_call_response.name != REQUEST_EUC_FUNCTION_CALL_NAME:
        continue

      # found the function call response for the system long running request euc
      # function call
      auth_responses_by_long_running_tool_id[function_call_response.id] = (
          function_call_response.response
      )
    if not auth_responses_by_long_running_tool_id:
      return

    for i in range(len(events) - 2, -1, -1):
      event = events[i]
      # looking for the system long running reqeust euc function call
      function_calls = event.get_function_calls()
      if not function_calls:
        continue

      auth_responses_by_tool_id = {}

      for function_call in function_calls:
        if function_call.id not in auth_responses_by_long_running_tool_id:
          continue
        args = AuthToolArguments.model_validate(function_call.args)

        function_call_id = args.function_call_id
        auth_responses_by_tool_id[function_call_id] = (
            auth_responses_by_long_running_tool_id[function_call.id]
        )
      if not auth_responses_by_tool_id:
        continue
      # found the the system long running reqeust euc function call
      # looking for original function call that requests euc
      for j in range(i - 1, -1, -1):
        event = events[j]
        function_calls = event.get_function_calls()
        if not function_calls:
          continue
        for function_call in function_calls:
          function_response_event = None
          if function_call.id in auth_responses_by_tool_id:
            function_response_event = functions.handle_function_calls(
                invocation_context,
                event,
                {tool.name: tool for tool in agent.canonical_tools},
                # there could be parallel function calls that require auth
                # auth response would be a dict keyed by function call id
                auth_responses_by_tool_id,
            )
          if function_response_event:
            yield function_response_event
          return
      return


request_processor = _AuthLlmRequestProcessor()
