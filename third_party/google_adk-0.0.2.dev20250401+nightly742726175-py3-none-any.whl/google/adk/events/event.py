# Copyright 2025 Google LLC
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from datetime import datetime
import random
import string
from typing import Optional

from google.genai import types
from pydantic import ConfigDict
from pydantic import Field

from ..models.llm_response import LlmResponse
from .event_actions import EventActions


class Event(LlmResponse):
  model_config = ConfigDict(
      extra='forbid', ser_json_bytes='base64', val_json_bytes='base64'
  )

  # TODO: revert to be required after spark migration
  invocation_id: str = ''
  # The name of the agent that sent the event, or user.
  author: str
  actions: EventActions = Field(default_factory=EventActions)

  long_running_tool_ids: Optional[set[str]] = None
  """Set of ids of the long running function calls.
  Agent client will know from this field about which function call is long running.
  only valid for function call event
  """
  branch: Optional[str] = None
  """The branch of the event.

  The format is like agent_1.agent_2.agent_3, where agent_1 is the parent of
  agent_2, and agent_2 is the parent of agent_3.

  Branch is used when multiple sub-agent shouldn't see their peer agents'
  conversaction history.
  """

  # The following are computed fields.
  # Do not assign the ID. It will be assigned by the session.
  id: str = ''
  timestamp: float = Field(default_factory=lambda: datetime.now().timestamp())

  def model_post_init(self, __context):
    # Generates a random ID for the event.
    if not self.id:
      self.id = Event.new_id()

  def is_final_response(self) -> bool:
    if self.actions.skip_summarization or self.long_running_tool_ids:
      return True
    return (
        not self.get_function_calls()
        and not self.get_function_responses()
        and not self.partial
        and not self.has_trailing_code_exeuction_result()
    )

  def get_function_calls(self) -> list[types.FunctionCall]:
    func_calls = []
    if self.content and self.content.parts:
      for part in self.content.parts:
        if part.function_call:
          func_calls.append(part.function_call)
    return func_calls

  def get_function_responses(self) -> list[types.FunctionResponse]:
    func_response = []
    if self.content and self.content.parts:
      for part in self.content.parts:
        if part.function_response:
          func_response.append(part.function_response)
    return func_response

  def has_trailing_code_exeuction_result(
      self,
  ) -> bool:
    if self.content:
      if self.content.parts:
        return self.content.parts[-1].code_execution_result is not None
    return False

  @staticmethod
  def new_id():
    characters = string.ascii_letters + string.digits
    return ''.join(random.choice(characters) for _ in range(8))

  @classmethod
  def from_function_response(
      cls,
      function_call_event,
      function_call,
      function_result,
  ):
    function_response = types.FunctionResponse(
        name=function_call.name, response=function_result, id=function_call.id
    )

    content = types.Content(
        role='user',
        parts=[types.Part(function_response=function_response)],
    )
    return cls(
        invocation_id=function_call_event.invocation_id,
        author=function_call_event.author,
        content=content,
    )
