# Copyright 2025 Google LLC
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import json
import logging
import os

from google.adk.cli.utils import create_empty_state
from google.adk.sessions.session import Session
import pandas as pd
import streamlit as st

from . import agent_tab
from . import app_context
from . import chat

logger = logging.getLogger(__name__)


def render():
  if not st.session_state.demo_name:
    return
  if app_context.is_remote_mode():
    return

  # Render current agent name
  current_agent = st.session_state.get('demo_name', None)

  if not current_agent:
    st.info('Please select an agent first in Agent tab.')
    return

  st.selectbox(
      'Evalaution Sets',
      get_eval_sets(),
      index=None,
      placeholder='Select a eval set...',
      key='eval_sets',
  )

  st.button('Refresh', key='refresh_eval_sets_button')

  if st.button('Create new eval set', use_container_width=True):
    create_new_eval_set_dialog()
  if st.session_state.get('eval_sets', None) == None:
    st.warning('Select an evaluation set to get started.')
    return
  else:
    if st.button('Save current session as eval case', use_container_width=True):
      save_session_as_test_file_dialog()

    # Render evaluation file selection
    select_evaluations()

    render_eval_cases()
    if not st.session_state.get('run_tests'):
      render_eval_results()
    st.session_state['run_tests'] = False

    # Load Selected Session
    load_session_with_eval()


def get_eval_sets():
  agent_folder = os.path.join(
      app_context.get_agent_folder(), st.session_state.demo_name
  )
  eval_sets_names = [
      x
      for x in os.listdir(agent_folder)
      if os.path.isfile(os.path.join(agent_folder, x))
      and not x.startswith('.')
      and x != '__pycache__'
      and x.endswith('.evalset.json')
  ]
  eval_sets_names.sort()
  return eval_sets_names


def select_evaluations():
  eval_set_path = get_eval_set_path()
  col1, col2 = st.columns(2)
  if col1.button(
      'Run Select',
      use_container_width=True,
      key='open_test_files_popup',
  ):
    selected_case_index = st.session_state.get('selected_case')
    if not selected_case_index:
      st.warning('No evaluation cases selected.')

    st.session_state['run_tests'] = True
    st.session_state['test_file_selection'] = [eval_set_path]

  if col2.button(
      'Run All',
      use_container_width=True,
      key='run_all_tests_button',
  ):
    with open(eval_set_path, 'r') as file:
      eval_set_data = json.load(file)  # Load JSON into a list
    st.session_state['selected_case'] = range(len(eval_set_data))
    st.session_state['run_tests'] = True
    st.session_state['test_file_selection'] = [eval_set_path]

  # Run the selected test files
  if st.session_state.get('run_tests'):
    run_tests(st.session_state.get('test_file_selection', []))


def load_session_with_eval():
  if (
      'session_to_load' in st.session_state
      and st.session_state['session_to_load']
  ):

    st.write(f"✅ Loading session: {st.session_state['session_to_load']}")
    selected_eval_file = st.session_state['session_to_load']
    session_name = selected_eval_file.rsplit('.test', 1)[0]

    session_path = os.path.join(
        app_context.get_agent_folder(),
        st.session_state.demo_name,
        session_name + '.session.json',
    )

    eval_path = os.path.join(
        app_context.get_agent_folder(),
        st.session_state.demo_name,
        session_name + '.test.json',
    )

    # Check if the session file exists
    if not os.path.exists(session_path) or not os.path.exists(eval_path):
      st.error(f'❌ File not found: {session_path}')
      st.session_state['session_to_load'] = None  # Clear temporary state
      return

    with open(session_path, 'r') as f:
      st.session_state.session = Session.model_validate_json(f.read())

    with open(eval_path, 'r') as f:
      st.session_state.eval = json.load(f)
      logger.info('loaded eval file: %s', eval_path)

    st.session_state['session_to_load'] = None  # Clear temporary state
    st.rerun()


def run_tests(test_file):
  if not test_file or not st.session_state.get('selected_case'):
    st.warning('No eval selected for testing.')
    return

  progress_section = st.empty()
  with progress_section.container():
    st.write('### Running Evaluations')
    progress = st.progress(0)
    with open(test_file[0], 'r') as file:
      test_data = json.load(file)  # Load JSON into a list
  test_data = [
      obj
      for i, obj in enumerate(test_data)
      if i in st.session_state.get('selected_case')
  ]
  total_files = len(test_data)
  test_results = []

  col1, col2 = st.columns([8, 2])
  col1.text('Case')
  col2.text('Result')
  test_file = test_file[0]
  for idx, test_case in enumerate(test_data):
    try:
      # Load evaluation criteria for the current file
      from google.adk.evaluation.agent_evaluator import AgentEvaluator
      from google.adk.evaluation.trajectory_evaluator import TrajectoryEvaluator

      evaluation_criteria = AgentEvaluator.find_config_for_test_file(test_file)

      agent_name = st.session_state.get('demo_name', 'unknown_agent')

      num_runs = 1
      evaluation_response = None
      evaluation_response = AgentEvaluator._generate_responses(
          agent_name, [test_case['data']], num_runs=num_runs
      )
      score = TrajectoryEvaluator.evaluate(evaluation_response)

      # Check against criteria
      threshold = evaluation_criteria.get('tool_trajectory_avg_score', 1.0)
      result = '✅' if score >= threshold else '❌'
    except Exception as e:
      result = f'❌ Error - {str(e)}'
      logger.info('Error: %s', str(e))

    # Append results
    test_result = {'Case Name': test_case['name'], 'Result': result}
    test_results.append(test_result)
    render_eval_result(idx, test_result)
    # Update progress
    progress.progress((idx + 1) / total_files)

  st.session_state['test_results'] = test_results
  progress_section.empty()


def render_eval_results():
  if (
      'test_results' not in st.session_state
      or not st.session_state['test_results']
  ):
    st.info('Run an evaluation to see results.')
    return
  col1, col2 = st.columns([8, 2])
  col1.text('File')
  col2.text('Result')

  test_results_df = pd.DataFrame(st.session_state['test_results'])

  for index, row in test_results_df.iterrows():
    render_eval_result(index, row)


def render_eval_result(index, row):
  col1, col2 = st.columns([8, 2])
  with col1:
    st.write(row['Case Name'].removesuffix('.test.json'))
  with col2:
    if st.button(row['Result'], key=f'load_session_btn_{index}'):
      file_path = row['File Path']
      st.session_state['session_to_load'] = os.path.splitext(
          os.path.basename(file_path)
      )[0]


# File Selection Dialog
@st.dialog('Select Evaluation Files to Run')
def select_test_files_popup():
  st.write('### Select Files for Evaluation')

  # Fetch test files
  eval_files_directory = os.path.abspath(
      os.path.join(app_context.get_agent_folder(), st.session_state.demo_name)
  )
  test_files = [
      os.path.join(root, file)
      for root, _, files in os.walk(eval_files_directory)
      for file in files
      if file.endswith('.test.json')
  ]

  if not test_files:
    st.warning('No test files found.')
    return

  # Prepare selection table
  test_data = {
      'Select': [
          os.path.basename(file)
          in st.session_state.get('test_file_selection', [])
          for file in test_files
      ],
      'File Name': [os.path.basename(file) for file in test_files],
  }
  test_df = pd.DataFrame(test_data)

  # Display editable table
  edited_test_df = st.data_editor(
      test_df, use_container_width=True, key='test_file_selection_table'
  )

  # Update selected test files
  st.session_state['test_file_selection'] = [
      test_files[i]
      for i, selected in enumerate(edited_test_df['Select'])
      if selected
  ]

  if st.button('Run Selected Tests'):
    st.session_state['run_tests'] = True
    st.session_state['run_all_tests'] = (
        False  # Ensure only selected tests are run
    )
    st.rerun()


@st.dialog('Create new evaluation set')
def create_new_eval_set_dialog():
  eval_set_name = st.text_input(
      'Evaluation Set Name',
      key='eval_set_name_input',
  )
  save_button_clicked = st.button('Save', key='eval_set_save_button')
  if save_button_clicked:
    try:
      new_eval_set_str = json.dumps([], indent=2)

      # Define the file path
      new_eval_set_path = os.path.join(
          app_context.get_agent_folder(),
          st.session_state.demo_name,
          eval_set_name + '.evalset.json',
      )

      # Write the JSON string to the file
      with open(new_eval_set_path, 'w') as f:
        f.write(new_eval_set_str)

      # Provide feedback on the UI
      st.success(f'File saved successfully as: {new_eval_set_path}')
      st.rerun()
    except Exception as e:
      # Display an error message if something goes wrong
      st.error(f'An error occurred while saving the file: {str(e)}')


@st.dialog('Save current session as an eval case')
def save_session_as_test_file_dialog():
  case_name = st.text_input(
      'Test case name',
      value=st.session_state.selected_session,
      key='case_name_input',
  )
  save_button_clicked = st.button('Save', key='test_file_save_button')

  if save_button_clicked:
    try:
      eval_set_path = get_eval_set_path()
      with open(eval_set_path, 'r') as file:
        eval_set_data = json.load(file)  # Load JSON into a list
      # Convert the session data to evaluation format
      test_data = convert_session_format_to_eval_format(
          st.session_state.session.model_dump()
      )

      # Create a dummy session to get initial session state
      dummy_session = app_context.get_session_service().create_session(
          st.session_state.session.app_name, 'test_user'
      )

      # Populate the session with initial session state.
      if initialize_empty_state := create_empty_state(
          app_context.get_root_agent()
      ):
        app_context.update_session_state(initialize_empty_state)

      eval_set_data.append({
          'name': case_name,
          'data': test_data,
          'initial_state': {'session': dummy_session.state},
      })
      # Serialize the test data to JSON
      # test_data_str = json.dumps(test_data, indent=2)
      # Write the JSON string to the file
      with open(eval_set_path, 'w') as f:
        f.write(json.dumps(eval_set_data, indent=2))

      # Provide feedback on the UI
      st.success(f'File saved successfully as: {eval_set_path}')
      st.rerun()

    except Exception as e:
      # Display an error message if something goes wrong
      st.error(f'An error occurred while saving the file: {str(e)}')


def load_eval_into_session(session, i, eval_dataset_index, actual_tools):
  def render_eval_event(event_index, author, eval_event_index, tools_match):
    eval_event = st.session_state.eval[eval_event_index]
    expected_tools = eval_event.get('expected_tool_use', [])

    # Create a new row for the evaluation
    chat_row = st.container(key=f'chat_row_eval_{event_index}')
    with chat_row:
      # Render the avatar for the evaluation
      chat.render_avatar(author, event_index, 0)
      with st.container():
        if not tools_match:
          st.markdown('**Evaluation (❌): Mismatch Detected**')
        else:
          if expected_tools:
            st.markdown('**Evaluation (✅): Expected Tools Used**')
          else:
            return  # If no expected tools, return early

        # Render tools in a horizontal layout
        for tool_index, tool in enumerate(expected_tools):
          render_eval_tool_button(eval_event_index, tool, tool_index)

  @st.fragment
  def render_eval_tool_button(eval_event_index, tool, tool_index):
    tool_text = f"⚡ {tool.get('tool_name', 'Unknown Tool')}"
    tool_details = tool.get('tool_input', {})
    unique_key = (
        f'eval_tool_{eval_event_index}_{tool.get("tool_name")}_{tool_index}'
    )

    # Render the popup and button
    with st.popover(tool_text):
      st.write('### Tool Details')
      st.json(tool_details)
      st.button(
          tool_text,
          key=unique_key,
          help='Click to view details',  # Optional tooltip
          on_click=lambda: None,  # Trigger the popup display
      )

  if 'eval' not in st.session_state:
    return
  if i - 1 >= 0 and session.events[i - 1].author == 'user':
    eval_event = st.session_state.eval[eval_dataset_index]
    expected_tools = eval_event.get('expected_tool_use', [])
    if not expected_tools:
      eval_dataset_index += 1
      actual_tools = []
      return eval_dataset_index
    from google.adk.evaluation.trajectory_evaluator import TrajectoryEvaluator

    actual_processed = [
        {'tool_name': tool.name, 'tool_input': tool.args}
        for tool in actual_tools
    ]
    expected_processed = [
        {'tool_name': tool['tool_name'], 'tool_input': tool['tool_input']}
        for tool in expected_tools
    ]
    tools_match = TrajectoryEvaluator.are_tools_equal(
        actual_processed, expected_processed
    )

    render_eval_event(i, 'evaluation', eval_dataset_index, tools_match)

    eval_dataset_index += 1
    actual_tools = []
    return eval_dataset_index
  return eval_dataset_index


def render_eval_cases():
  if st.session_state.get('eval_sets', None) == None:
    st.warning('Select an evaluation set to get started.')
    return
  eval_set_path = get_eval_set_path()
  with open(eval_set_path, 'r') as file:
    eval_set_data = json.load(file)  # Load JSON into a list
  if len(eval_set_data) == 0:
    st.warning('No evaluation cases found.')
    return
  st.session_state['selected_case'] = []
  col1, col2 = st.columns(2)
  with col1:
    st.text('Evaluation Case')
  with col2:
    st.text('Select')
  casecol1, casecol2 = st.columns(2)
  for i, eval_case in enumerate(eval_set_data):
    with casecol1:
      st.write(eval_case['name'])
    with casecol2:
      if st.checkbox(
          '{i}', label_visibility='hidden', key=f'selected_case_{i}'
      ):
        st.session_state['selected_case'].append(i)


def convert_session_format_to_eval_format(session_file):
  """Converts a single session file in the new format into the accepted evaluation format.

  Args:
      session_file (dict): The detailed session log.

  Returns:
      list: A single evaluation dataset in the required format.
  """
  eval_case = []
  events = session_file.get('events', [])

  for event in events:
    if event.get('author') == 'user':
      # Extract user query
      content = event.get('content', {})
      parts = content.get('parts', [])
      if not parts:
        continue

      query = parts[0].get('text', '')  # Safely get the query text

      # Find the corresponding tool usage or response for the query
      expected_tool_use = []
      intermediate_agent_responses = []

      # Check subsequent events to extract tool uses or responses for this turn.
      for subsequent_event in events[events.index(event) + 1 :]:
        event_author = subsequent_event.get('author', 'agent')
        if event_author == 'user':
          # We found an event where the author was the user. This means that a
          # new turn has started. So close this turn here.
          break

        subsequent_content = subsequent_event.get('content', {})
        if not subsequent_content:
          continue
        subsequent_parts = subsequent_content.get('parts', [])
        if not subsequent_parts:
          continue

        for subsequent_part in subsequent_parts:
          # Some events have both function call and reference

          # Safely check for function_call
          function_call = subsequent_part.get('function_call', None)
          if function_call:
            tool_name = function_call.get('name', '')
            tool_input = function_call.get('args', {})
            expected_tool_use.append({
                'tool_name': tool_name,
                'tool_input': tool_input,
            })
          elif 'text' in subsequent_part and subsequent_part['text']:
            # Also keep track of all the natural langauge responses that
            # agent (or sub agents) generated.
            intermediate_agent_responses.append(
                {'author': event_author, 'text': subsequent_part['text']}
            )

      # If we are here then either we are done reading all the events or we
      # encountered an event that had content authored by the end-user.
      # This, basically means an end of turn.
      # We assume that the last natural langauge intermediate response is the
      # final response from the agent/model. We treat that as a reference.
      eval_case.append({
          'query': query,
          'expected_tool_use': expected_tool_use,
          'expected_intermediate_agent_responses': intermediate_agent_responses[
              :-1
          ],
          'reference': (
              intermediate_agent_responses[-1]['text']
              if intermediate_agent_responses
              else ''
          ),
      })

  return eval_case


def get_eval_set_path():
  eval_set_filename = st.session_state.get('eval_sets')
  return os.path.join(
      app_context.get_agent_folder(),
      st.session_state.demo_name,
      eval_set_filename,
  )
