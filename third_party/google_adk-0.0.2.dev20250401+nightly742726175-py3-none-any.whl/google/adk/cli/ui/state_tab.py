# Copyright 2025 Google LLC
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import json

import streamlit as st


def save_state():
  session = st.session_state.session
  session.state = json.loads(st.session_state.get('state_json', ''))
  st.session_state.edit_state = False


def cancel_edit_state():
  st.session_state.edit_state = False


def start_edit_state():
  st.session_state.edit_state = True


# st.fragment is needed to avoid rerun the whole, in which case the state
# wont'be updated.
@st.fragment
def render():
  if not st.session_state.demo_name:
    return

  session = st.session_state.session

  if st.session_state.edit_state:
    with st.container(key='row_layout_state'):
      st.button('Save', on_click=save_state)
      st.button('Cancel', on_click=cancel_edit_state)
    state_json = json.dumps(session.state, indent=2)
    st.text_area(
        'Edit',
        state_json,
        height=500,
        key='state_json',
    )
  else:
    st.button('Edit', on_click=start_edit_state)
    st.write(session.state)
