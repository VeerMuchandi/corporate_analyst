# Copyright 2025 Google LLC
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import json

from google.adk.flows.llm_flows import functions
from google.adk.tools.auth_tool import AuthToolArguments
from google.genai import types
import streamlit as st

from . import app_context

run_every = None


@st.fragment(run_every=run_every)
def auto_refresh_for_pending_events():
  session = st.session_state.session
  if st.session_state.event_num != len(session.events):
    st.session_state.event_num = len(session.events)
    st.rerun()


def start_or_stop_auto_refresh_for_pending_events():
  global run_every
  session = st.session_state.session
  if get_pending_events(session):
    run_every = '3s'
    auto_refresh_for_pending_events()
  else:
    run_every = None


@st.dialog('Pending event')
def pending_event_dialog(
    function_call_event,
    function_call,
    function_response_content,
):
  st.write(f'Pending function call: {function_call.name}')
  st.json(function_call.args)
  redirect_uri = 'http://localhost/oauth_callback'
  if function_call.name == functions.REQUEST_EUC_FUNCTION_CALL_NAME:
    args = AuthToolArguments.model_validate_json(json.dumps(function_call.args))
    st.markdown(
        f'<a href="{args.auth_config["auth_uri"][0]}&redirect_uri={redirect_uri}"'
        ' target="_blank">Authorize</a>',
        unsafe_allow_html=True,
    )

  with st.form('result_form'):
    result = st.text_area('Result')
    if st.form_submit_button('Submit'):
      result_value = json.loads(result) if result.startswith('{') else result
      if not isinstance(result_value, dict):
        result_value = {'response': result_value}
      if function_call.name == functions.REQUEST_EUC_FUNCTION_CALL_NAME:
        result_value['redirect_uri'] = redirect_uri
      function_response = types.FunctionResponse(
          name=function_call.name, response=result_value
      )
      function_response.id = function_call.id

      function_response_content.parts.append(
          types.Part(function_response=function_response)
      )
      if len(function_response_content.parts) == len(
          function_call_event.long_running_tool_ids
      ):

        # when all the function responses are generated
        session = st.session_state.session

        list(
            app_context.get_runner().run(
                user_id=session.user_id,
                session_id=session.id,
                new_message=function_response_content,
                streaming=st.session_state.get('streaming', False),
            )
        )
      st.rerun()


def render_pending_events_button():
  session = st.session_state.session
  start_or_stop_auto_refresh_for_pending_events()

  pending_events = get_pending_events(session)
  with st.popover(
      'Pending events'
      f' ({sum([len(e.long_running_tool_ids) for e in pending_events])})',
      use_container_width=True,
  ):
    for pending_event in pending_events:
      function_response_content = types.Content(
          role='user',
          parts=[],
      )
      function_calls = pending_event.get_function_calls()
      for function_call in function_calls:
        if function_call.id not in pending_event.long_running_tool_ids:
          continue
        if function_call.name == functions.REQUEST_EUC_FUNCTION_CALL_NAME:
          name = 'OAuth Requested'
        else:
          name = (
              f"{function_call.name}({','.join([str(x) for x in function_call.args.values()])})"
          )
        if st.button(
            name,
            key=f'pending_{pending_event.id}_{name}',
            use_container_width=True,
        ):
          pending_event_dialog(
              pending_event,
              function_call,
              function_response_content,
          )


def get_pending_events(session):
  events = session.events
  pending = []
  for i in range(len(events) - 1, -1, -1):
    event = events[i]
    if event.get_function_calls():
      if event.long_running_tool_ids:
        pending.append(event)
  return pending
