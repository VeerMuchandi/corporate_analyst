# Copyright 2025 Google LLC
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import json
import os

import streamlit as st

from . import agent_graph
from . import app_context


@st.dialog('Event', width='large')
def show():
  root_agent = app_context.get_root_agent()
  session = st.session_state.session
  col1, col2, col3 = st.columns([90, 5, 5], vertical_alignment='center')
  has_previous = st.session_state.event_dialog_index > 0
  has_next = st.session_state.event_dialog_index < len(session.events) - 1

  with col2:
    if st.button('⇦', disabled=not has_previous):
      if has_previous:
        st.session_state.event_dialog_index -= 1

  with col3:
    if st.button('⇨', disabled=not has_next):
      if has_next:
        st.session_state.event_dialog_index += 1

  event_index = st.session_state.event_dialog_index
  event = session.events[event_index]
  text = get_event_info(event)

  with col1:
    # Uses radio buttons because they are faster than tabs.
    tabs = ['Event', 'Graph', 'Request', 'Response']
    if 'event_dialog_info_type' not in st.session_state:
      st.session_state.event_dialog_info_type = 'Event'
    info_type = st.segmented_control(
        f'Event {event_index + 1} of {len(session.events)}: {text}',
        tabs,
        selection_mode='single',
        key='event_dialog_info_type',
    )

  call_llm_span = st.session_state.call_llm_spans.get(event.id, None)
  if info_type == 'Event':
    if call_llm_span:
      project_id = os.environ.get('GOOGLE_CLOUD_PROJECT', '')
      trace_id = f"{call_llm_span['trace_id']:x}"
      span_id = f"{call_llm_span['span_id']:x}"
      st.link_button(
          'Trace',
          f'https://console.cloud.google.com/traces/explorer;traceId={trace_id};spanId={span_id}&project={project_id}',
      )
    st.write(event.model_dump(exclude_none=True))

  if info_type == 'Graph':
    function_calls = event.get_function_calls()
    function_responses = event.get_function_responses()
    if function_calls:
      function_call_highlights = []
      for function_call in function_calls:
        from_name = event.author
        to_name = function_call.name
        function_call_highlights.append((from_name, to_name))
      st.graphviz_chart(
          agent_graph.get_agent_graph(root_agent, function_call_highlights)
      )
    elif function_responses:
      function_responses_highlights = []
      for function_response in function_responses:
        from_name = function_response.name
        to_name = event.author
        function_responses_highlights.append((from_name, to_name))
      st.graphviz_chart(
          agent_graph.get_agent_graph(root_agent, function_responses_highlights)
      )
    else:
      from_name = event.author
      to_name = ''
      st.graphviz_chart(
          agent_graph.get_agent_graph(root_agent, [(from_name, to_name)])
      )

  if info_type == 'Request':
    if call_llm_span:
      if 'gcp.vertex.agent.llm_request' in call_llm_span:
        st.write(json.loads(call_llm_span['gcp.vertex.agent.llm_request']))
      if 'gcp.vertex.agent.data' in call_llm_span:
        st.write(json.loads(call_llm_span['gcp.vertex.agent.data']))
    else:
      st.write('No logs found for the event.')

  if info_type == 'Response':
    if call_llm_span and 'gcp.vertex.agent.llm_response' in call_llm_span:
      st.write(json.loads(call_llm_span['gcp.vertex.agent.llm_response']))
    else:
      st.write('No logs found for the event.')


def get_event_info(event):
  function_calls = event.get_function_calls()
  function_responses = event.get_function_responses()
  text = ''
  if function_calls:
    for function_call in function_calls:
      text = f'⚡ {function_call.name}'
  elif function_responses:
    for function_response in function_responses:
      icon = '✔️'
      text = f'{icon} {function_response.name}'
  elif event.is_final_response():
    text = (
        event.content.role if event.content and event.content.role else 'model'
    )
    text += ': '
    if event.content and event.content.parts:
      for part in event.content.parts:
        if part.text:
          text += part.text
        elif part.inline_data and part.inline_data.mime_type.startswith(
            'image/'
        ):
          text += ' [IMAGE] '
        elif part.inline_data:
          text += ' [File] '
    else:
      text += ' This event is empty.'
  else:
    raise ValueError(f'Unsupported event: {event}')
  return text
