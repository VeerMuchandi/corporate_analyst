# Copyright 2025 Google LLC
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import logging
from typing import Generator

from google.adk.events.event import Event
from google.genai import types
import requests
import streamlit as st

logger = logging.getLogger(__name__)


def create_session(app_name: str, user_id: str, session_id: str):
  server_url: str = st.session_state.demo_name
  url = f'{server_url}/apps/{app_name}/users/{user_id}/sessions/{session_id}'
  response = requests.post(url, json={}, timeout=120)
  logger.info('Creating session, status: %s', response.status_code)
  # TODO: refresh st.session_state.session from the response.


def run(
    app_name: str, user_id: str, session_id: str, new_message: types.Content
) -> Generator[Event, None, None]:
  server_url: str = st.session_state.demo_name
  url = f'{server_url}/agent/run'
  headers = {'Content-Type': 'application/json'}
  payload = {
      'app_name': app_name,
      'user_id': user_id,
      'session_id': session_id,
      'new_message': new_message.model_dump(),
  }
  response = requests.post(url, headers=headers, json=payload, timeout=120)
  logger.info('Running agent, status: %s', response.status_code)

  if response.status_code == 200:
    event_dict_list = response.json()
    logger.info(
        'Got %s events from server: %s', len(event_dict_list), event_dict_list
    )
    # TODO: Fix this hack by change elsewhere to read session from runner.
    for event_dict in event_dict_list:
      event = Event.model_validate(event_dict)
      st.session_state.session_service.append_event(
          st.session_state.session, event
      )
      yield event
  else:
    raise RuntimeError(f'Failed to run agent, status: {response.status_code}')
