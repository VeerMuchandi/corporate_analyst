# Copyright 2025 Google LLC
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import asyncio
import logging
import os
import shlex
import subprocess
from typing import Optional

import click
from dotenv import load_dotenv
import streamlit.web.bootstrap as bootstrap
import uvicorn

from .cli import run_cli
from .cli_eval import MISSING_EVAL_DEPENDENCIES_MESSAGE
from .fast_api import get_fast_api_app
from .utils import logs

logger = logging.getLogger(__name__)


@click.group()
def main():
  """Agent Development Kit CLI tools."""
  pass


@main.command("run")
@click.option(
    "--json_file",
    type=click.Path(
        exists=True, dir_okay=False, file_okay=True, resolve_path=True
    ),
    help=(
        "The json file in the agent folder, either a *.input.json or"
        " *.session.json."
    ),
)
@click.option(
    "--save_session",
    type=bool,
    is_flag=True,
    show_default=True,
    default=False,
    help="Whether to save the session to a json file on exit.",
)
@click.argument(
    "agent",
    type=click.Path(
        exists=True, dir_okay=True, file_okay=False, resolve_path=True
    ),
)
def cli_run(agent: str, json_file: str, save_session: bool):
  """Run an interactive CLI for a certain agent."""
  logs.log_to_tmp_folder()

  agent_parent_folder = os.path.dirname(agent)
  agent_folder_name = os.path.basename(agent)

  asyncio.run(
      run_cli(
          agent_parent_dir=agent_parent_folder,
          agent_folder_name=agent_folder_name,
          json_file_path=json_file,
          save_session=save_session,
      )
  )


@main.command()
@click.option(
    "--launch_browser",
    is_flag=True,
    show_default=True,
    default=False,
    help="Whether to launch browser automatically.",
)
@click.option(
    "--log_to_tmp",
    is_flag=True,
    show_default=True,
    default=False,
    help=(
        "Whether to log to system temp folder instead of console. This is"
        " useful for local debugging."
    ),
)
@click.option("--session_db_url", help="The database URL to store the session.")
@click.option(
    "--agent_engine_id",
    help="The Vertex Agent Engine resource id to host the managed session.",
)
@click.option(
    "--log_level",
    type=click.Choice(
        ["DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"], case_sensitive=False
    ),
    default="INFO",
    help="Set the logging level",
)
@click.argument(
    "agent_dir",
    type=click.Path(
        exists=True, dir_okay=True, file_okay=False, resolve_path=True
    ),
    default=os.getcwd(),
)
def streamlit(
    agent_dir: str,
    launch_browser: bool,
    log_to_tmp: bool,
    session_db_url: str = "",
    agent_engine_id: str = "",
    log_level: str = "INFO",
):
  """Start the web app server to test multiple agents.

  AGENT_DIR: the directory of agents, where each sub-directory is a single
  agent. By default, it is the current working directory.
  """
  if log_to_tmp:
    logs.log_to_tmp_folder()
  else:
    logs.log_to_stderr()

  app_script_path = os.path.join(os.path.dirname(__file__), "ui/web.py")

  flag_options = {
      "server.headless": not launch_browser,
      "browser.serverAddress": "localhost",
      "server.enableCORS": False,
      "server.enableXsrfProtection": False,
  }
  logging.getLogger().setLevel(log_level)
  bootstrap.load_config_options(flag_options)
  bootstrap.run(
      app_script_path,
      False,
      [agent_dir, session_db_url, agent_engine_id],
      flag_options,
  )


@main.command("eval")
@click.argument(
    "agent_module_file_path",
    type=click.Path(
        exists=True, dir_okay=True, file_okay=False, resolve_path=True
    ),
)
@click.argument("eval_set_file_path", nargs=-1)
@click.option("--config_file_path", help="The path to config file.")
@click.option(
    "--print_detailed_results",
    is_flag=True,
    show_default=True,
    default=False,
    help="Whether to print detailed results on console or not.",
)
def eval(
    agent_module_file_path: str,
    eval_set_file_path: tuple[str],
    config_file_path: str,
    print_detailed_results: bool,
):
  """Evaluates an agent given the eval sets.

  AGENT_MODULE_FILE_PATH: The path to the __init__.py file that contains a
  module by the name "agent". "agent" module contains a root_agent.

  EVAL_SET_FILE_PATH: You can specify one or more eval set file paths.

  For each file, all evals will be run by default.

  If you want to run only specific evals from a eval set, first create a comma
  separated list of eval names and then add that as a suffix to the eval set
  file name, demarcated by a `:`.

  For example,

  sample_eval_set_file.json:eval_1,eval_2,eval_3

  This will only run eval_1, eval_2 and eval_3 from sample_eval_set_file.json.

  CONFIG_FILE_PATH: The path to config file.

  PRINT_DETAILED_RESULTS: Prints detailed results on the console.
  """
  load_dotenv(override=True, verbose=True)

  try:
    from .cli_eval import EvalMetric
    from .cli_eval import EvalResult
    from .cli_eval import EvalStatus
    from .cli_eval import get_evaluation_criteria_or_default
    from .cli_eval import get_root_agent
    from .cli_eval import parse_and_get_evals_to_run
    from .cli_eval import run_evals
    from .cli_eval import try_get_reset_func
  except ModuleNotFoundError:
    raise click.ClickException(MISSING_EVAL_DEPENDENCIES_MESSAGE)

  evaluation_criteria = get_evaluation_criteria_or_default(config_file_path)
  eval_metrics = []
  for metric_name, threshold in evaluation_criteria.items():
    eval_metrics.append(
        EvalMetric(metric_name=metric_name, threshold=threshold)
    )

  print(f"Using evaluation creiteria: {evaluation_criteria}")

  root_agent = get_root_agent(agent_module_file_path)
  reset_func = try_get_reset_func(agent_module_file_path)

  eval_set_to_evals = parse_and_get_evals_to_run(eval_set_file_path)

  try:
    eval_results = list(
        run_evals(
            eval_set_to_evals,
            root_agent,
            reset_func,
            eval_metrics,
            print_detailed_results=print_detailed_results,
        )
    )
  except ModuleNotFoundError:
    raise click.ClickException(MISSING_EVAL_DEPENDENCIES_MESSAGE)

  print("*********************************************************************")
  eval_run_summary = {}

  for eval_result in eval_results:
    eval_result: EvalResult

    if eval_result.eval_set_file not in eval_run_summary:
      eval_run_summary[eval_result.eval_set_file] = [0, 0]

    if eval_result.final_eval_status == EvalStatus.PASSED:
      eval_run_summary[eval_result.eval_set_file][0] += 1
    else:
      eval_run_summary[eval_result.eval_set_file][1] += 1
  print("Eval Run Summary")
  for eval_set_file, pass_fail_count in eval_run_summary.items():
    print(
        f"{eval_set_file}:\n  Tests passed: {pass_fail_count[0]}\n  Tests"
        f" failed: {pass_fail_count[1]}"
    )


@main.command("web")
@click.option(
    "--log_to_tmp",
    is_flag=True,
    show_default=True,
    default=False,
    help=(
        "Whether to log to system temp folder instead of console. This is"
        " useful for local debugging."
    ),
)
@click.option("--session_db_url", help="The database URL to store the session.")
@click.option(
    "--agent_engine_id",
    help="The Vertex Agent Engine resource id to host the managed session.",
)
@click.option(
    "--log_level",
    type=click.Choice(
        ["DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"], case_sensitive=False
    ),
    default="INFO",
    help="Set the logging level",
)
@click.option(
    "--allow_origins",
    help="Any additional origins to allow for CORS.",
    multiple=True,
)
@click.argument(
    "agent_dir",
    type=click.Path(
        exists=True, dir_okay=True, file_okay=False, resolve_path=True
    ),
    default=os.getcwd(),
)
def web(
    agent_dir: str,
    log_to_tmp: bool,
    session_db_url: str = "",
    agent_engine_id: str = "",
    log_level: str = "INFO",
    allow_origins: Optional[list[str]] = None,
):
  """Start a FastAPI server for a certain agent."""
  if log_to_tmp:
    logs.log_to_tmp_folder()
  else:
    logs.log_to_stderr()

  logging.getLogger().setLevel(log_level)

  config = uvicorn.Config(
      get_fast_api_app(
          app_dir=agent_dir,
          session_db_url=session_db_url,
          agent_engine_id=agent_engine_id,
          allow_origins=allow_origins,
          web=True,
      ),
      host="0.0.0.0",
      port=8000,
      reload=True,
  )
  server = uvicorn.Server(config)
  server.run()


@main.command("api_server")
@click.option(
    "--log_to_tmp",
    is_flag=True,
    show_default=True,
    default=False,
    help=(
        "Whether to log to system temp folder instead of console. This is"
        " useful for local debugging."
    ),
)
@click.option("--session_db_url", help="The database URL to store the session.")
@click.option(
    "--agent_engine_id",
    help="The Vertex Agent Engine resource id to host the managed session.",
)
@click.option(
    "--log_level",
    type=click.Choice(
        ["DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"], case_sensitive=False
    ),
    default="INFO",
    help="Set the logging level",
)
@click.option(
    "--allow_origins",
    help="Any additional origins to allow for CORS.",
    multiple=True,
)
@click.argument(
    "agent_dir",
    type=click.Path(
        exists=True, dir_okay=True, file_okay=False, resolve_path=True
    ),
    default=os.getcwd(),
)
def cli_api_server(
    agent_dir: str,
    log_to_tmp: bool,
    session_db_url: str = "",
    agent_engine_id: str = "",
    log_level: str = "INFO",
    allow_origins: Optional[list[str]] = None,
):
  if log_to_tmp:
    logs.log_to_tmp_folder()
  else:
    logs.log_to_stderr()

  logging.getLogger().setLevel(log_level)

  config = uvicorn.Config(
      get_fast_api_app(
          app_dir=agent_dir,
          session_db_url=session_db_url,
          agent_engine_id=agent_engine_id,
          allow_origins=allow_origins,
          web=False,
      ),
      host="0.0.0.0",
      port=8000,
      reload=True,
  )
  server = uvicorn.Server(config)
  server.run()


@main.command("deploy")
@click.option("--cloud_project_name", type=str)
@click.option("--service_name", type=str)
@click.option("--agent_name", type=str)
@click.option(
    "--with_ui",
    is_flag=True,
    default=False,
    help="Deploy with Streamlit UI (port 8501).",
)
def cli_deploy(
    cloud_project_name: str,
    service_name: str,
    agent_name: str,
    with_ui: bool = False,
):
  """Deploy a FastAPI server or a streamlit UI version for a certain agent to Cloud Run."""
  command = (
      f"gcloud run deploy {service_name} --source . --region=us-central1"
      " --no-allow-unauthenticated --set-env-vars"
      f" GOOGLE_GENAI_USE_VERTEXAI=1,GOOGLE_CLOUD_PROJECT={cloud_project_name},"
      f"AGENT_NAME={agent_name},GOOGLE_CLOUD_LOCATION=us-central1"
  )
  if with_ui:
    command += (
        ",DEPLOYMENT_ENV=with_ui --ingress all --port 8501 --memory 4G"
        " --cpu-boost --timeout=300s"
    )
  else:
    command += " --port=8000 "

  print(command)

  subprocess.run(shlex.split(command))
